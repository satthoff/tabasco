There used to be a sample program here ... it's been replaced with
'ccreport' in the ./examples section of ClearCase::Argv. That one is a
cleaned-up and enhanced version of daily_changes.pl, also ported to the
ClearCase::Argv abstraction.
